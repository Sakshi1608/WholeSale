<?php
$servername="localhost";
$username="root";
$password="";
$dbname="wholesale";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
    die("Connection failed:".$conn->connect_error);
}
//echo"CONNECTION ESTABLISHED\r\n";
//echo"Insertion in process";
$Ret_id = $_POST["Ret_id"];
$CP_Ret = $_POST["CP_Ret"];
$SP_Ret = $_POST["SP_Ret"];
$P_id = $_POST["P_id"];
$Dis_id = $_POST["Dis_id"];
$sql="UPDATE Retailer SET Cp_ret='$CP_Ret',Sp_ret='$SP_Ret',Product_id='$P_id', S_dis_id='$Dis_id' WHERE Ret_id='$Ret_id'";
if($conn->query($sql)==true){
    echo "<script>
    alert('SUCCESSFULLY UPDATED');
    window.location.href='Rdisplay.php';
    </script>";
}
else{
    echo "error:".$sql."<br>".$conn->error;
}
$conn->close();
?>


