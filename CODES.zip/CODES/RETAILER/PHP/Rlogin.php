<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "wholesale";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$R_id=$_POST["R_id"];
$Pass=$_POST["pass"];
$sql = "SELECT PassWord FROM Retailer WHERE Ret_id='$R_id' AND PassWord='$Pass'";
$result = $conn->query($sql);

if($conn->query($sql)==true){
    if ($result->num_rows > 0){
    echo "<script>
    alert('LOGIN SUCCESSFUL');
    window.location.href='Rpage.html';
    </script>";
    }   
    else{
        echo "<script>
        alert('INCORRECT USERNAME OR PASSWORD');
        window.location.href='Rlogin.html';
        </script>";
    }
}

else{echo "nothing";}

$conn->close();
?>