<!DOCTYPE html>
<html>
<head>
<style>
    @import url(https://fonts.googleapis.com/css?family=Open+Sans:400,600);

*, *:before, *:after {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  background-image:url(ret.jfif);
  background-size:cover;
  font-family: 'Open Sans', sans-serif;
}
table {
  background:  #012B39;
  border-radius: 0.25em;
  border-collapse: collapse;
  margin: 1em;
}
th {
  border-bottom: 1px solid #364043;
  color: #E2B842;
  font-size: 0.85em;
  font-weight: 600;
  padding: 0.5em 1em;
  text-align: left;
}
td {
  color: #fff;
  font-weight: 400;
  padding: 0.65em 1em;
}
.disabled td {
  color: #4F5F64;
}
tbody tr {
  transition: background 0.25s ease;
}
tbody tr:hover {
  background: #014055;
}

</style>
</head>
<body>
    <center>
    <table>
        <tr>
            <th>Ret_id</th>
            <th>Cp_ret</th>
            <th>Sp_ret</th>
            <th>Product_id</th>
            <th>S_Dis_id</th>
        </tr>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "wholesale";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT Ret_id, Cp_ret, Sp_ret, Product_id, S_dis_id FROM retailer";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["Ret_id"]."</td><td>".$row["Cp_ret"]."</td><td>".$row["Sp_ret"]."</td><td>".$row["Product_id"]."</td><td>".$row["S_dis_id"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
?>


</table>
<a href="RetP.html" ><center>Back</center></a>
</center>
</body>
</html>
