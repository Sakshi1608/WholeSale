<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "wholesale";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: ".$conn->connect_error);
}
$Rid=$_POST["Ret_id"];
// sql to delete a record
$sql = "DELETE FROM Retailer WHERE Ret_id='$Rid' ";

if($conn->query($sql)==true){
    echo " <script>
    alert('SUCCESSFULLY DELETED');
    window.location.href='Rdisplay.php';
    </script>";
}
else{
    echo "error:".$sql."<br>".$conn->error;
}

$conn->close();
?>