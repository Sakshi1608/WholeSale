<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "wholesale";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: ".$conn->connect_error);
}
$Sid=$_POST["S_id"];
// sql to delete a record
$sql = "DELETE FROM supplier WHERE Sp_id='$Sid' ";

if($conn->query($sql)==true){
    echo " <script>
    alert('SUCCESSFULLY DELETED');
    window.location.href='Mdisplay.php';
    </script>";
}
else{
    echo "error:".$sql."<br>".$conn->error;
}

$conn->close();
?>