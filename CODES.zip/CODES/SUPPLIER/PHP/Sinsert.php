<?php
$servername="localhost";
$username="root";
$password="";
$dbname="wholesale";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
    die("Connection failed:".$conn->connect_error);
}
//echo"CONNECTION ESTABLISHED\r\n";
//echo"Insertion in process";
$SP_id = $_POST["S_id"];
$CP_SP = $_POST["CP_SP"];
$SP_SP = $_POST["SP_SP"];
$P_id = $_POST["P_id"];
$Pass=$_POST["pass"];
$Time=$_POST["date"];
$sql="INSERT INTO supplier VALUES('$SP_id','$Pass','$CP_SP','$SP_SP','$P_id','$Time')";
if($conn->query($sql)==true){
    echo "<script>
    alert('SUCCESSFULLY REGISTERED.Registration Date:Auto');
    window.location.href='Slogin.html';
    </script>";
}
else{
    echo "error:".$sql."<br>".$conn->error;
}
$conn->close();
?>