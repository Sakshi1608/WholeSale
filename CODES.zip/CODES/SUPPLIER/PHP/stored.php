<!DOCTYPE html>
<html>
<head>
<style>
    @import url(https://fonts.googleapis.com/css?family=Open+Sans:400,600);

*, *:before, *:after {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  background-image:url(product12.jfif);
  background-size:cover;
  font-family: 'Open Sans', sans-serif;
}
table {
  background: #012B39;
  border-radius: 0.25em;
  border-collapse: collapse;
  margin: 1em;
}
th {
  border-bottom: 1px solid #364043;
  color: #E2B842;
  font-size: 0.85em;
  font-weight: 600;
  padding: 0.5em 1em;
  text-align: left;
}
td {
  color: #fff;
  font-weight: 400;
  padding: 0.65em 1em;
}
.disabled td {
  color: #4F5F64;
}
tbody tr {
  transition: background 0.25s ease;
}
tbody tr:hover {
  background: #014055;
}

</style>
</head>
<body>
    <center>
    <table>
    <table>
                <tr>
                <th>Product Name</th>
                    <th>Total Price</th>
                    <th>Cost Price</th>
                    <th>Selling Price</th>
                    <th>Supplier id</th>         
                </tr>
        <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "wholesale";
        // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
        
            $procin=$_POST["P_id"];
            
            
            $sql = "
            SELECT P.Product_name,P.Total_Price,S.Cp_supplier,S.Sp_supplier,S.Sp_id
            from product P, supplier S
            where P.Product_id=S.Product_id And P.Product_id='$procin'";
            
            $result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
               
                echo "<tr><td>".$row["Product_name"]."</td><td>".$row["Total_Price"]."</td><td>".$row["Cp_supplier"]."</td><td>".$row["Sp_supplier"]."</td><td>".$row["Sp_id"]."</td></tr>";
            }
        
            echo "</table>";
        }
        else {
            echo "0 results";
        }
        
        
            $conn->close();
            ?>
            </table>
</body>
</html>


        
    