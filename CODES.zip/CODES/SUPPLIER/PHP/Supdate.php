<?php
$servername="localhost";
$username="root";
$password="";
$dbname="wholesale";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
    die("Connection failed:".$conn->connect_error);
}
//echo"CONNECTION ESTABLISHED\r\n";
//echo"Insertion in process";
$S_id = $_POST["S_id"];
$CP_SP = $_POST["CP_SP"];
$SP_SP = $_POST["SP_SP"];
$P_id = $_POST["P_id"];
$sql="UPDATE supplier SET Cp_supplier='$CP_SP',Sp_supplier='$SP_SP',Product_id='$P_id',  WHERE Sp_id='$S_id'";
if($conn->query($sql)==true){
    echo "<script>
    alert('SUCCESSFULLY UPDATED');
    window.location.href='Mdisplay.php';
    </script>";
}
else{
    echo "error:".$sql."<br>".$conn->error;
}
$conn->close();
?>


