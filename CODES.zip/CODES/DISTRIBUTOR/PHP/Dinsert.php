<?php
$servername="localhost";
$username="root";
$password="";
$dbname="wholesale";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
    die("Connection failed:".$conn->connect_error);
}
//echo"CONNECTION ESTABLISHED\r\n";
//echo"Insertion in process";
$D_id = $_POST["D_id"];
$CP_Dis = $_POST["CP_Dis"];
$SP_Dis = $_POST["SP_Dis"];
$P_id= $_POST["P_id"];
$S_id = $_POST["S_id"];
$Pass=$_POST["pass"];
$sql="INSERT INTO distributor VALUES('$D_id','$Pass','$CP_Dis','$SP_Dis','$P_id','$S_id')";
if($conn->query($sql)==true){
    echo "<script>
    alert('SUCCESSFULLY ENTERED');
    window.location.href='Dlogin.html';
    </script>";
}
else{
    echo "error:".$sql."<br>".$conn->error;
}
$conn->close();
?>