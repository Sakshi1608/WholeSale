<?php
$servername="localhost";
$username="root";
$password="";
$dbname="wholesale";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
    die("Connection failed:".$conn->connect_error);
}
//echo"CONNECTION ESTABLISHED\r\n";
//echo"Insertion in process";
$D_id = $_POST["D_id"];
$CP_Dis = $_POST["CP_Dis"];
$SP_Dis = $_POST["SP_Dis"];
$P_id= $_POST["P_id"];
$S_id = $_POST["S_id"];
$sql="UPDATE Distributor SET Cp_dis='$CP_Dis',Sp_dis='$SP_Dis',Product_id='$P_id', SuperSp_id='$S_id' WHERE Dis_id='$D_id'";
if($conn->query($sql)==true){
    echo "<script>
    alert('SUCCESSFULLY UPDATED');
    window.location.href='Ddisplay.php';
    </script>";
}
else{
    echo "error:".$sql."<br>".$conn->error;
}
$conn->close();
?>


