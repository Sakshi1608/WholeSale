<!DOCTYPE html>
<html>
<head>
<style>
    @import url(https://fonts.googleapis.com/css?family=Open+Sans:400,600);

*, *:before, *:after {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  background-image:url(product12.jfif);
  background-size:cover;
  font-family: 'Open Sans', sans-serif;
}
table {
  background: #012B39;
  border-radius: 0.25em;
  border-collapse: collapse;
  margin: 1em;
}
th {
  border-bottom: 1px solid #364043;
  color: #E2B842;
  font-size: 0.85em;
  font-weight: 600;
  padding: 0.5em 1em;
  text-align: left;
}
td {
  color: #fff;
  font-weight: 400;
  padding: 0.65em 1em;
}
.disabled td {
  color: #4F5F64;
}
tbody tr {
  transition: background 0.25s ease;
}
tbody tr:hover {
  background: #014055;
}

</style>
</head>
<body>
    <center>
    <table>
    <tr>
    <th>Dis_id</th>
    <th>Cp_dis</th>
    <th>Sp_dis</th>
    <th>Product_id</th>
    <th>SuperSp_id</th>
    </tr>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "wholesale";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$D_id=$_POST["D_id"];

$sql = "SELECT Dis_id, Cp_dis, Sp_dis, Product_id, SuperSp_id  FROM distributor WHERE Dis_id='$D_id'";
$result=$conn->query($sql);

if ($result->num_rows > 0) {
    ;
    
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["Dis_id"]."</td><td>".$row["Cp_dis"]."</td><td>".$row["Sp_dis"]."</td><td>".$row["Product_id"]."</td><td>".$row["SuperSp_id"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
?>
</table>
</center>
</body>
</html>
