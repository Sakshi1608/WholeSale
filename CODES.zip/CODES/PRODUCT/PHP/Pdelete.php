<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "wholesale";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: ".$conn->connect_error);
}
$P_id=$_POST["P_id"];
// sql to delete a record
$sql = "DELETE FROM product WHERE Product_id='$P_id' ";

if($conn->query($sql)==true){
    echo " <script>
    alert('SUCCESSFULLY DELETED');
    window.location.href='Pdelete.html';
    </script>";
}
else{
    echo "error:".$sql."<br>".$conn->error;
}

$conn->close();
?>