<!DOCTYPE html>
<html>
<head>
<style>
    @import url(https://fonts.googleapis.com/css?family=Open+Sans:400,600);

*, *:before, *:after {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  background-image:url(product12.jfif);
  background-size:cover;
  font-family: 'Open Sans', sans-serif;
}
table {
  background: #012B39;
  border-radius: 0.25em;
  border-collapse: collapse;
  margin: 1em;
}
th {
  border-bottom: 1px solid #364043;
  color: #E2B842;
  font-size: 0.85em;
  font-weight: 600;
  padding: 0.5em 1em;
  text-align: left;
}
td {
  color: #fff;
  font-weight: 400;
  padding: 0.65em 1em;
}
.disabled td {
  color: #4F5F64;
}
tbody tr {
  transition: background 0.25s ease;
}
tbody tr:hover {
  background: #014055;
}

</style>
</head>
<body>
    <center>
    <table>
    <tr>
    <th>Product_id</th>
    <th>Product_Name</th>
    <th>Total_Price</th>
    <th>M_id</th>
    <th>Mgr_Mid</th>
    <th>SSP_id</th>
    </tr>
 
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "wholesale";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$P_id=$_POST["P_id"];

$sql = "SELECT Product_id, Product_name, Total_Price, M_id, Mgr_Mid, SSP_id FROM product where Product_id='$P_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["Product_id"]."</td><td>".$row["Product_name"]."</td><td>".$row["Total_Price"]."</td><td>".$row["M_id"]."</td><td>".$row["Mgr_Mid"]."</td><td>".$row["SSP_id"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "<script>
    alert('INVALID.ENTER AGAIN!!');
    window.location.href='Psearch.html';
    </script>";
}
$conn->close();
?>
</table>
</center>
</body>
</html>
