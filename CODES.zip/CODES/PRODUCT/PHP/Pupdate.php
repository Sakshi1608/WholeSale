<?php
$servername="localhost";
$username="root";
$password="";
$dbname="wholesale";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
    die("Connection failed:".$conn->connect_error);
}
//echo"CONNECTION ESTABLISHED\r\n";
//echo"Insertion in process";
$P_id = $_POST["P_id"];
$P_Name = $_POST["P_Name"];
$TP = $_POST["TP"];
$MD = $_POST["MD"];
$MGID = $_POST["MGID"];
$SPID = $_POST["SPID"];
$sql="UPDATE product SET Product_Name='$P_Name',Total_Price='$TP', M_id='$MD',Mgr_Mid='$MGID',SSP_id='$SPID' WHERE Product_id='$P_id'";
if($conn->query($sql)==true){
    echo "<script>
    alert('SUCCESSFULLY UPDATED');
    window.location.href='Ppage.html';
    </script>";
}
else{
    echo "<script>
    alert('INVALID.ENTER AGAIN!!');
    window.location.href='Pupdate.html';
    </script>";
}
$conn->close();
?>


