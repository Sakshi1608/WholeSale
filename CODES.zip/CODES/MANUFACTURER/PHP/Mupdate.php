<?php
$servername="localhost";
$username="root";
$password="";
$dbname="wholesale";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
    die("Connection failed:".$conn->connect_error);
}
//echo"CONNECTION ESTABLISHED\r\n";
//echo"Insertion in process";
$M_id = $_POST["M_id"];
$M_Name = $_POST["M_Name"];
$RMN = $_POST["RMN"];
$RMNO = $_POST["RMNO"];
$RMP = $_POST["RMP"];
$sql="UPDATE Manufacturer SET M_name='$M_Name',Raw_m_Name='$RMN',Raw_m_Quantity='$RMNO', Raw_m_Price='$RMP' WHERE M_id='$M_id'";
if($conn->query($sql)==true){
    echo "<script>
    alert('SUCCESSFULLY UPDATED');
    window.location.href='Mdisplay.php';
    </script>";
}
else{
    echo "error:".$sql."<br>".$conn->error;
}
$conn->close();
?>


