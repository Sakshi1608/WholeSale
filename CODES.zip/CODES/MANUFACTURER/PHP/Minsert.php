<?php
$servername="localhost";
$username="root";
$password="";
$dbname="wholesale";
$conn=new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
    die("Connection failed:".$conn->connect_error);
}
//echo"CONNECTION ESTABLISHED\r\n";
//echo"Insertion in process";
$M_id = $_POST["M_id"];
$M_Name = $_POST["M_Name"];
$Pass=$_POST["pass"];
$RMN = $_POST["RMN"];
$RMNO = $_POST["RMNO"];
$RMP = $_POST["RMP"];
$sql="INSERT INTO manufacturer VALUES('$M_id','$Pass','$M_Name','$RMN','$RMNO','$RMP')";
if($conn->query($sql)==true){
    echo "<script>
    alert('SUCCESSFULLY REGISTERED');
    window.location.href='Mlogin.html';
    </script>";
}
else{
    echo "error:".$sql."<br>".$conn->error;
}
$conn->close();
?>