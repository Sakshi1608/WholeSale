<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "wholesale";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$M_id=$_POST["M_id"];
$Pass=$_POST["pass"];
$sql = "SELECT PassWord FROM manufacturer WHERE M_id='$M_id' AND PassWord='$Pass'";
$result = $conn->query($sql);

if($conn->query($sql)==true){
    if ($result->num_rows > 0){
    echo "<script>
    alert('LOGIN SUCCESSFUL');
    window.location.href='Mpage.html';
    </script>";
    }   
    else{
        echo "<script>
        alert('INCORRECT USERNAME OR PASSWORD');
        window.location.href='Mlogin.html';
        </script>";
    }
}

else{echo "nothing";}

$conn->close();
?>
